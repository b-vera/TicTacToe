// pch = strtok (line," ,.-");
// while (pch != NULL) {
//     printf ("%s\n",pch);
//     pch = strtok (NULL, " ,.-");
// }
#include "programa.h"

Plays * createPlays() {
    Plays * list = (Plays *)malloc(sizeof(Plays));
    list->len  = 0;
    list->move = NULL;
    return list;
}

void addMove(Plays * list,char * namePlayer,char * movePlayer){

    Move * value = (Move *)malloc(sizeof(Move));

    value->name     = namePlayer;
    value->move     = movePlayer;
    value->len_move = 0;
}

void inciar(){
    Plays * plays = createPlays();
    leerArchivo("prueba.txt",plays);
}
