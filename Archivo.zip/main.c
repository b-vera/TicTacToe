#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "lecturaArchivo.h"
#include "programa.h"

int main() {
    iniciar();
    return 0;
}
